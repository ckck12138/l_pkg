#' newton
#' @description
#' Estimate regression coefficient using the Newtonian descent method
#'
#' @param x Independent Variable
#' @param y dependent Variable
#'
#' @return \eqn{\hat{\beta}}
#' @export \eqn{\hat{\beta}}
#'
#' @examples
#' set.seed(123)
#' n=100
#' p=4
#' x<-matrix(rnorm(rnorm(n*p)),nrow=n)
#' y<-rbinom(n,1,0.5)
#' newton(x,y)
#'

newton<-function(x,y){
  beta=matrix(0,nrow=p+1)
  beta_new=matrix(1,nrow=p+1)
  p=ncol(x)#维数
  xx<-cbind(1,x)
  for(i in 1:1000){
    w1=exp(xx%*%beta)#100*1
    w2=w1/(1+w1)#100*1
    w3=w2*(1-w2)
    hessen=1/n*t(xx)%*%diag(as.vector(w3))%*%xx
    grad=1/n*t(xx)%*%(w2-y)
    beta_new=beta-solve(hessen)%*%grad
    beta=beta_new

  }
  return(beta)
}
