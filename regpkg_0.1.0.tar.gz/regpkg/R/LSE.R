#' LSE
#' @description
#' Estimate linear regression coefficient using the Least Squares method
#'
#' @param x Independent Variable, a matrix or vector
#' @param y dependent Variable, a matrix or vector
#'
#' @return \eqn{\hat{\beta}}
#' @export \eqn{\hat{\beta}}
#'
#' @examples
#' set.seed(123)
#' n=100
#' p=4
#' x<-matrix(rnorm(rnorm(n*p)),nrow=n)
#' y<-rbinom(n,1,0.5)
#' LSE(x,y)
#'

LSE<-function(x,y){
  xx<-cbind(1,x)
  beta=solve(t(xx)%*%xx)%*%t(xx)%*%y
  return(beta)
}

