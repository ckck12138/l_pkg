#' gradient
#' @description
#' Estimate linear regression coefficient using the Gradient descent method.
#'
#' @param x Independent Variable, a matrix or vector
#' @param y dependent Variable, a matrix or vector
#' @param r Step size , when it is too large, the initial decline speed is very fast, but it is possible to cross the lowest point, so you can adopt the strategy of first large and then small to adjust the step size, and the specific size can be adjusted according to the reduction of the function.
#'
#' @return \eqn{\hat{\beta}}
#' @export \eqn{\hat{\beta}}
#'
#' @examples
#' set.seed(123)
#' n=100
#' p=4
#' x<-matrix(rnorm(rnorm(n*p)),nrow=n)
#' y<-rbinom(n,1,0.5)
#' gradient(x,y,0.1)
#'
gradient<-function(x,y,r){
  beta=matrix(0,nrow=p+1)
  beta_new=matrix(1,nrow=p+1)
  p=ncol(x)
  xx<-cbind(1,x)
  for(i in 1:1000){
    w1=exp(xx%*%beta)
    w2=w1/(1+w1)
    w3=w2*(1-w2)
    grad=1/n*t(xx)%*%(w2-y)
    beta_new=beta-r*grad
    beta=beta_new

  }
  return(beta)
}

